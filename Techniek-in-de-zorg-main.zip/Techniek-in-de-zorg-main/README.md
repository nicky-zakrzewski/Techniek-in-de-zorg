# Techniek-in-de-zorg
Godot game voor techniek in de zorg
